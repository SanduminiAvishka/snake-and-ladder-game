#!/usr/bin/env bash

steam-run ~/Android/Sdk/emulator/emulator -avd Tiramisu_720p -dns-server 8.8.8.8
