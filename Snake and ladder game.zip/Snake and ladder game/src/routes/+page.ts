export const load = async ({ url }) => {
	return { url }
}
