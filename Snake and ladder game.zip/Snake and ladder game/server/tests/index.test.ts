// import { expect, test } from 'vitest'
// import { growth } from '../src/index'

// test('growth', () => {
// 	expect(growth(10, 15)).toBe(0.5)
// 	expect(growth(15, 10)).toBeCloseTo(-0.33, 2)
// 	expect(growth(10, 8)).toBe(-0.2)
// 	expect(growth(10, 10)).toBe(0)
// })
